def main() -> None:
    print("Hello from ai-telephone!")
